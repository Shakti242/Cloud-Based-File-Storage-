export const REGION = 'us-east-1';
export const DYNAMODB_TABLE_NAME = 'ImageMetaData';
export const S3_BUCKET_NAME = 'storage-bucket-project';
